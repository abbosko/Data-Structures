#include <iostream>
#include <cstdlib>
#include <stdlib.h>
#include <string.h>



using namespace std;


template <typename keytype>
class FibHeap {
private:

struct FibNode {
    keytype key;
    int degree;
    FibNode *parent, *child, *next, *prev, *right;
};

FibNode *min;
FibNode *head;
FibNode *tail;


FibNode* newNode(keytype key, int degree){
    FibNode* temp = new FibNode;
    temp->key = key;
    temp->degree = degree;
    temp->parent = NULL;
    temp->child = NULL;
    temp->next = NULL;
   temp-> prev = NULL;
   temp->right = NULL;

    return temp;
}


public:
FibHeap(){  
    // min = new FibNode;
    // head = new FibNode;
    // tail = new FibNode;                       // default constructor, empty heap
    min = NULL;
    head = NULL;
    tail = NULL;
}


FibHeap(keytype k[], int s){
    // min = new FibNode;
    // head = new FibNode;
    // tail = new FibNode;

    min = newNode(k[0], 0);
    head=min;
    tail=min;
  
  for(int i=1; i< s; i++){
      insert(k[i]);
  }
  //heapSize =s;

    consolidate();

}  

FibHeap(const FibHeap <keytype> &src) {
  

 head = copyNode(src.head);
     tail=copyNode(src.tail);
     min = copyNode(src.min);
    // //this->min = src.min;
    //this->tail = srthisc.tail;
    // tail->next = NULL;
    // head->prev = NULL;
   
    FibNode *ptr2 = head;
    while(ptr2 != NULL){
        ptr2 =  CopyHelper(ptr2);
        ptr2 = ptr2->next;
        }

    // head = copyNode(src.head);
    //  tail=copyNode(src.tail);
    //  min = copyNode(src.min);
    // // //this->min = src.min;
    // //this->tail = srthisc.tail;
    // // tail->next = NULL;
    // // head->prev = NULL;
   
    // FibNode *ptr = head;
    // while(ptr != NULL){
    //     ptr =  CopyHelper(ptr);
    //     ptr = ptr->next;
    //     }
        //delete head;
        //delete tail;
        //delete min;
    
      //  ptr = ptr->next;
    
//   tail->next= NULL;
        //  head = new FibNode;
        //  tail = new FibNode;
        //  min = new FibNode;

    // head = src.head;
    // min = src.min;
    // tail = src.tail;
    // tail->next = NULL;
    // head->prev = NULL;
   
    // FibNode *ptr = src.head;
    // FibNode *ptr2 = src.head->next;
    // while(ptr2 != NULL){
    //     copyNode(ptr2);
    //     CopyHelper(ptr2->child);
    //     ptr2 = ptr2->next;
    //     ptr = ptr->next;
    // }
    // ptr->next = NULL;
    // tail->next = NULL;
    // head->prev = NULL;

        // head = src.head;
        // tail = src.tail;
        // min = src.min;

        // FibNode *prev = src.head;
        // FibNode *curr = src.head->next;
        // while(curr != NULL){
        //     FibNode *temp = new FibNode;
        //     temp->key = curr->key;
        //     temp->degree =curr->degree;
        //     temp->parent = curr->parent;
        //     temp->child = curr->child;
        //     temp->next = curr->next;
        //     temp-> prev = prev;
        //     temp->right = curr->right;
        //          if(curr->child != NULL){
        //              FibNode *temp2 = new FibNode;
        //                 temp2->key = curr->child->key;
        //                 temp2->degree =curr->child->degree;
        //                 temp2->parent = curr->child->parent;
        //                 temp2->child = curr->child->child;
        //                 temp2->next = curr->child->next;
        //                 temp2-> prev = curr->child->prev;
        //                 temp2->right = curr->child->right;
                
        //         if (curr->child->right != NULL){
        //             FibNode *temp3 = new FibNode;
        //                 temp3->key = curr->child->key;
        //                 temp3->degree =curr->childdegree;
        //                 temp3->parent = curr->child->parent;
        //                 temp3->child = curr->child->child;
        //                 temp3->next = curr->child->next;
        //                 temp3-> prev = curr->child->prev;
        //                 temp3->right = curr->child->right;
                    
        //         }
        //         }
        //         curr = curr->next;
        //         prev = prev->next;
        // }
   }



FibNode* CopyHelper(FibNode *root){
    if (root == NULL){
    return NULL; }
 
   FibNode* node = copyNode(root);
  // if(node->child != NULL){
     node->child = CopyHelper(root->child);
 //if(node->child->right != NULL){
    node->right = CopyHelper(root->right);
    
   

   return node;

}

FibNode* copyNode(FibNode *curr){
    if(curr == NULL){

      return NULL;
    }
    FibNode *temp = new FibNode;
            temp->key = curr->key;
            temp->degree = curr->degree;
            temp->parent = curr->parent;
            temp->child = curr->child;
            temp->next = curr->next;
            temp-> prev = curr->prev;
            temp->right = curr->right;
    return temp;
}


 FibHeap& operator=(const FibHeap<keytype>  &src){
    
//    FibNode *head = new FibNode;
//      FibNode *tail = new FibNode;
//       FibNode *min = new FibNode;
    this->head = copyNode(src.head);
     this->tail=copyNode(src.tail);
     this->min = copyNode(src.min);
    // //this->min = src.min;
    //this->tail = srthisc.tail;
    // tail->next = NULL;
    // head->prev = NULL;
   
    FibNode *ptr = head;
    while(ptr != NULL){
        ptr =  CopyHelper(ptr);
        ptr = ptr->next;
        }
        return *this;
    //this->head = src.head;
    // FibNode *head = new FibNode;
    //  FibNode *tail = new FibNode;
    //   FibNode *min = new FibNode;
    //  head = copyNode(src.head);
    //  tail=copyNode(src.tail);
    //  min = copyNode(src.min);
    // // //this->min = src.min;
    // //this->tail = srthisc.tail;
    // // tail->next = NULL;
    // // head->prev = NULL;
   
    // FibNode *ptr = head;
    // FibNode *ptr2 = head->next;
    // while(head != NULL){
    //     copyNode(head->next );
    //     CopyHelper(head->next ->child);
    //     head =head->next;
    //     }
      //  ptr = ptr->next;
    
//   tail->next= NULL;
//    ptr->next = NULL;
//    tail->next = NULL;
//    head->prev = NULL;

    //  for(FibNode *ptr = head; ptr != NULL; ptr=ptr->next){
    //      if(ptr->key < min->key){
    //          min = ptr;
    //      }

    //  }

//cout <<  " HERE BITCH" << head->key << " " << head->next->key << " ";//<< head->next->next->key << endl;


//         head = src.head;
//         head->prev = NULL;
//         tail = src.tail;
//         tail->prev = NULL;
//         min = src.min;

//         FibNode *prev = new FibNode;src.head;
//         FibNode *curr = src.head->next;
//         while(curr != NULL){
//             FibNode *temp = new FibNode;
//             temp->key = curr->key;
//             temp->degree = curr->degree;
//             temp->parent = curr->parent;
//             temp->child = curr->child;
//             temp->next = curr->next;
//             temp-> prev = prev;
//             temp->right = curr->right;
//                  if(curr->child != NULL){
//                      FibNode *temp2 = new FibNode;
//                         temp2->key = curr->child->key;
//                         temp2->degree =curr->child->degree;
//                         temp2->parent = curr->child->parent;
//                         temp2->child = curr->child->child;
//                         temp2->next = curr->child->next;
//                         temp2-> prev = curr->child->prev;
//                         temp2->right = curr->child->right;
                
//                 if (curr->child->right != NULL){
//                     FibNode *rightPtr = curr->child->right;
//                     while(rightPtr!= NULL){
//                         FibNode *temp3 = new FibNode;
//                         temp3->key = rightPtr->key;
//                         temp3->degree = rightPtr->degree;
//                         temp3->parent = rightPtr->parent;
//                         temp3->child = rightPtr->child;
//                         temp3->next = rightPtr->next;
//                         temp3-> prev = rightPtr->prev;
//                         temp3->right = rightPtr->right;

//                         rightPtr=rightPtr->right;
//                     }
//                 }
//                 }
//                 curr = curr->next;
//                 prev = prev->next;
//         }
// curr->next = NULL;

}

~FibHeap(){
    FibNode *ptr = head;
    //FibNode *end = tail->next;
    while(ptr != NULL){
        if(ptr->next == NULL){
            return;
        }
        FibNode *netP = ptr->next;
        DestructHelper(ptr);
        ptr = netP;
    }
head = NULL;
tail= NULL;
min = NULL;
    
}

void DestructHelper(FibNode *Tree){
    if (Tree == NULL){
        return;
    }
   
       if(Tree->child != NULL){
            DestructHelper(Tree->child);
         if(Tree->child->right != NULL){
            DestructHelper(Tree->right);
        }

   }
   delete Tree;
 // return;
//}

}

FibNode* link(FibNode *first, FibNode *second){
        FibNode *smaller;//= new FibNode;
        FibNode *bigger;//= new FibNode;

        if(first->key < second->key){
            smaller = first;
            bigger = second;
        }
        else {
            smaller =second;
            bigger = first;
        }

        bigger->right = smaller->child;
        smaller->child = bigger;
        bigger->parent =smaller;
        smaller->degree++;

        return smaller;
}
void consolidate(){
    FibNode *arr[50] = {NULL};
    
    FibNode *curr = head;
    FibNode *nextC;
    int temp;
   // tail->next = NULL;

        while (curr!= NULL) {
            nextC = curr->next;
            temp = curr->degree;
            while(temp < 50 && arr[temp]!= NULL ){
                curr = link(arr[temp], curr);
                arr[temp]= NULL;
                temp++;
            }

            arr[temp]= curr;
            curr = nextC;
        }
        //tail->next = head;

        //
            // nextC = curr->next;
            // temp = curr->degree;
            // while(temp < 50 && arr[temp]!= NULL ){
            //     curr = link(arr[temp], curr);
            //     arr[temp]= NULL;
            //     temp++;
            // }

            // arr[temp]= curr;
            // curr = nextC;
            //
        
           
      
        head = NULL;
        tail = NULL;
        min = NULL;
        curr = NULL;

        for(int i=0; i< 50; i++){

                if(arr[i] !=NULL){
                 
            
                    if(head == NULL){
                        head= arr[i];
                        min = arr[i];
                        curr = head;
                        head->prev =NULL;
                        head->next = NULL;

                    }
                    else {
                        curr->next = arr[i];
                        arr[i]->prev= curr;
                        arr[i]->next = NULL;
                        if(arr[i]->key < min->key){
                            min= arr[i];
                        }
                        curr = curr->next;
                    }
        }
        }
        tail = curr;
       // tail->next = NULL;
        //return;

}


keytype peekKey(){
    return min->key;
}

keytype extractMin(){
  
FibNode *oldMin= new FibNode;
oldMin= min;



if(oldMin->child == NULL){                                     // if min has no child cut it out;
        
   
    if(min == head){                                   // if min has no child cut it out;

           head = head->next;
           head->prev = NULL;
           // oldMin->prev->next = oldMin->next;
            //oldMin->next->prev = oldMin->prev;
         //return oldMin->key;
     }
    else if(min == tail){    
      
             tail->next = NULL;                                    // if min has no child cut it out;
            FibNode *shit=head;
            while(shit->next->next != NULL){
                shit=shit->next;
            }
            shit->next = NULL;
            tail->prev = shit->prev;
            tail = shit;
            tail->next = NULL;
            //cout << shit->key;
           // cout <<"Print";
        // tail = tail->prev;                         
        // tail->next = NULL;
        //oldMin->prev->next = oldMin->next;

           
            // oldMin->prev->next = NULL;
           // oldMin->next->prev = oldMin->prev;
         //return oldMin->key;
     }
     else {

            FibNode *prv=head;
            FibNode *curr = head->next;
            while ( curr != min) {
                curr=curr->next;
                prv=prv->next;
             
            }
        
            curr->next->prev= prv;
            prv->next = curr->next;

    //      while(pointer->next->next != NULL){
    //     oldMin->prev->next = oldMin->next;
    //     oldMin->next->prev = oldMin->prev; 
     }
    }

     
    else {//if(oldMin-> child !=NULL)  {   
       //    cout << " YO MAMAMAMAMAAM" << head->key; 
                               // if it has children
     FibNode *children = new FibNode;
     children = oldMin->child;          // point to child
     while(children != NULL){  
        children->prev = tail;                                // while it still has childre
        tail->next = children;          // add to root list
       // children->next = head;
        //children->prev = tail;
        tail = children;
        tail->next = NULL;
        children->parent = NULL;        // get rid of parent pointer

       // if(children->right->parent == oldMin){      // if right sibling has same parent
            children= children->right;
      //  }
        //else {
        //    children = NULL;
        }
     
        if(oldMin == head){ 
               
            head = head->next; 
            head->prev = NULL;
            tail->next = NULL;
        }
        else if(oldMin == tail){

            tail->next = NULL;                                    // if min has no child cut it out;
            FibNode *shit=head;
            while(shit->next->next != NULL){
                shit=shit->next;
            }
            shit->next = NULL;
            tail->prev = shit->prev;
            tail = shit;
            tail->next = NULL;


            // tail= min->prev;
            // tail
            // tail->next = NULL;
        }
        else {//(oldMin != tail && oldMin !=head){
         
            FibNode *ptr = head;
            while( ptr != oldMin){
                if(ptr->next != NULL){
                ptr = ptr->next; }
            }
            ptr->prev->next = ptr->next;                // i think infite loop?
            if(ptr->next != NULL){
                ptr->next->prev = ptr->prev;
            }

           // ptr= NULL;
            // FibNode *prv=head;
            // FibNode *curr = head->next;
            // while ( curr != oldMin) {              // ISSUES
            //     if(curr->next == NULL){
            //         break;
            //     }
            //     curr=curr->next;
            //     prv=prv->next;
            // }
            // curr->next->prev= prv;
            // prv->next = curr->next;                                      // cut out old min
        }
      }

     for(FibNode *ptr = head; ptr != NULL; ptr=ptr->next){
         if(ptr->key < min->key){
             min = ptr;
         }

     }
      
    consolidate();
 
    return oldMin->key;
}



void insert(keytype k){

    FibNode *temp = new FibNode;
    temp = newNode(k,0);

    if (min == NULL){
        // min = new FibNode;
        // head = new FibNode;
        // tail = new FibNode;
        min = temp;
        head = temp;
        head->prev = NULL;
        tail = temp;
        tail->next = NULL;
       // min->prev = tail;
       // min->next = min;
       // head->prev = tail;
        //tail->next = head;

    }
    else if (k < min->key){
        tail->next = temp;
        tail = tail->next;
        tail->next = NULL;
        //head->prev = tail;
        min = temp;
    }
    else {
        tail->next = temp; 
        tail = tail->next;
       tail->next = NULL;
      head->prev = NULL;;
    }
 // heapSize++;
}
void merge(FibHeap<keytype>&H2){
tail->next = H2.head;
    if(H2.min->key < min->key){
            min= H2.min;
   }
  // heapSize = heapSize + heapSize;
  
}

void  preorder(FibNode *root){
if (root == NULL){
    return; }
    
cout << root->key << " ";
 
preorder(root->child);
preorder(root->right);
}


void printKey(){
    FibNode *ptr = head;
    //FibNode *end = tail->next;
    
    while(ptr != NULL){
        cout <<"B" << ptr->degree << endl;
        cout << ptr->key << " ";
        preorder(ptr->child);
        cout << endl;
        ptr = ptr->next;
        cout << endl;
    }
    //  cout <<"B" << tail->degree << endl;
    //     cout << tail->key << " ";
    //     preorder(tail->child);
    //     cout << endl;
    //    // ptr = ptr->next;

    cout << endl;
    
}



void mincheck(){
    cout << min->key;
}

};
